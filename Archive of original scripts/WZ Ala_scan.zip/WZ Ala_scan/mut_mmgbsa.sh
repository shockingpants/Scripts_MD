#!/bin/bash
export AMBERHOME=/cluster/apps/x86_64/packages/amber11-patch/src
export PATH=$AMBERHOME/bin:$PATH

## Define first and last residue of mutation sequence 
FIRST=91
LAST=96
RES=ALA
PDB_FILE=../prot_0wat.pdb

# Determine the residues that can be mutated (omit Glycine and Alanine)
# First part, if substring from the resn colum is CA, print that line
# Same as just grepping actually
# Second part grabs lines without selected molecules
# Third part extracts characters at the 18-27 position of each line into a txt file. eg. ILE A 24
awk 'substr($0,14,3) == "CA "  {print($0)}' $PDB_FILE | egrep -v "ACE|PRO|NHE|NME|GLY|ALA" | cut -c '18-27' > residues_temp.txt

# This removes previous version of the files in case of repeat
rm residues1.txt dirlist.txt wt_seq.txt

# This greps for the lines corresponding to resi $FIRST to $LAST
# Note space between $i
for i in `seq $FIRST $LAST`;do
	grep "  $i " residues_temp.txt >> residues.txt
        # Fills the spaced with underscore to make directory names. Convenience
	grep "  $i " residues_temp.txt | tr ' ' '_' >> dirlist.txt
done
rm residues_temp.txt

# This creates a files called wt-seq.txt, which contains the 3 letter code of the primary sequence
awk '{print $1}' residues.txt >> wt_seq.txt
# Changes the file from 3 letter sequence to 1 letter sequence
sed -e "s/LYS/K/g" -e "s/ARG/R/g" -e "s/HIS/H/g" -e "s/ASP/D/g" -e "s/GLU/E/g" -e "s/PHE/F/g" -e "s/TYR/Y/g" -e "s/TRP/W/g" -e "s/SER/S/g" -e "s/THR/T/g" -e "s/CYS/C/g" -e "s/GLY/G/g" -e "s/ALA/A/g" -e "s/VAL/A/g" -e "s/ASN/N/g" -e "s/GLN/Q/g" -e "s/LEU/L/g" -e "s/MET/M/g" -e "s/ILE/I/g" -e "s/PRO/P/g" -e "s/HIE/H/g" wt_seq.txt >> wt_seq1letter.txt






# Creates a file of the chain
# Change column accordingly if you want to print resi instead
############################
awk '{print $2}' residues.txt >> chain_resn.txt 
############################









# Write into array (Note the use of (``), or equivalently ($()))
# To write everything into a line instead, use dirlist=`cat chain_resn.txt` or $(cat dirlist.txt)
dirlist=(`cat dirlist.txt`); chain_resn=(`cat chain_resn.txt`)
wt_seq=(`cat wt_seq.txt`)

# END now contains the number of element in  
BEGIN=1 ; END=`echo ${#dirlist[@]}`


############################
###### The main stuff
############################

# indexA is the line number
for indexA in `seq $BEGIN $END`;do
        # Math for right indexing
	index=`expr $indexA - 1`
        
        # Get residue number
	cur_chain_resn=`echo ${chain_resn[$index]}`
        # Get 'ILE A 24' that corresponds to the residue number
	spaced_residue=`cat residues.txt | grep "$cur_chain_resn"`
        # This is like a sed command, replaces the 3 letter aa in wt with ALA
	new_residue=${spaced_residue/${wt_seq[index]}/$RES}
	
        # This creates a new folder with all the intermediate folders
	mkdir -p ${dirlist[$index]}	
	cd ${dirlist[$index]}
	
	cp ../$PDB_FILE prot_0wat.pdb
        # -e lets every following " " be intepreted as a separate job
        # Replace the 3 letter aa code after N, CA, C and O into ala
	sed -e "s/N   $spaced_residue/N   $new_residue/" -e "s/CA  $spaced_residue/CA  $new_residue/" -e "s/C   $spaced_residue/C   $new_residue/" -e "s/O   $spaced_residue/O   $new_residue/" prot_0wat.pdb > TRANSITION.pdb
	# This grabs the part of the pdb that does not contain any of the side chain from the substituted side chain
        egrep -v "$spaced_residue" TRANSITION.pdb> mut.pdb
	rm TRANSITION.pdb prot_0wat.pdb
	
        # Split the PDB into its respective complex, receptor, and ligand
	/home/teojy/Scripts/splitpdb.py mut_rec.pdb mut_lig.pdb TEO.pdb < mut.pdb
	cp ../leap_mut_reclig.in .
	tleap -f leap_mut_reclig.in > myleap_mut_reclig.log
	
	cp ../mmpbsa.in .
	cp ../Alanine.sh .
	
	sed -i -e "s|__WORKDIR__|${dirlist[$index]}|g" -e "s|__PWD__|`pwd`|g" Alanine.sh
	
	qsub Alanine.sh
	cd ..
done

	
	
